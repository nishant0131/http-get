import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { ContactComponent } from './contact/contact.component';
import { ClientsComponent } from './clients/clients.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { CompanyComponent } from './company/company.component';
import { CareerComponent } from './career/career.component';
import { TechnologyComponent } from './technology/technology.component';
import { ServicesComponent } from './services/services.component';
import { HomeComponent } from './home/home.component';
import { Routes, RouterModule   } from '@angular/router';
import { routing } from "./app.routing";


@NgModule({
  declarations: [
    AppComponent,
    ContactComponent,
    ClientsComponent,
    PortfolioComponent,
    CompanyComponent,
    CareerComponent,
    TechnologyComponent,
    ServicesComponent,
    HomeComponent,
    
    
    

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule,
    routing
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
